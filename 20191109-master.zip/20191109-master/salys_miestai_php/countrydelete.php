<?php
include ('db_functions.php');
deleteCuntry($_GET['nr']);
   ?>
 <a  href="index.php" class="btn btn-outline-dark w-50 mb-5">Back to Home Page</a>
