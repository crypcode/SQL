<?php

define('DB_NAME', 'teltonika' );
define('MYSQL_USER', 'root' );
define('MYSQL_PASSWORD', 'root' );
define('DB_HOST', 'localhost' );

define('HOME_NUMBER_OF_ARTICLES', 20 );
define('RESULT_NUMBER_OF_ARTICLES', 20 );

 ?>
